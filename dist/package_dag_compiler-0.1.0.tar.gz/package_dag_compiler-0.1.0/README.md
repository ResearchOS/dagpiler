# Package DAG Compiler
 Tool to construct a DAG of a data processing pipeline. The pipeline is constructed from formatted TOML files.

Documentation: https://researchos.github.io/Package-DAG-Compiler/