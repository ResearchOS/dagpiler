# DAG Structure

!!!todo

1. Understand the types of DAG's that this compiler may generate. At the moment, it only puts out furcated (split) graphs. 
2. What does a split represent, why do I want it, and how do I trigger it?
3. 

- How the DAG is structured
    - Node naming conventions, and how it relates to TOML
    - Node metadata. Which metadata changes the hash?  

- Polyfurcations. What are they, when do they occur, why are they good, and what are the implementation details?
