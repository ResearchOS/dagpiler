# Template Structure

!!!todo

Templates for new projects can be created using `ros create $package_name`. This section defines the structure of the template. What is the directory structure, which files are included, what information needs to be entered in order to share the package? How to integrate with others' packages?